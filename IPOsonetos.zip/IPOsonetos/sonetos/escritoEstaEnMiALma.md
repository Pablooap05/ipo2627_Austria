Titulo: "Escrito está en mi alma"

Autor: "Garcilaso de la Vega"

Soneto:

Escrito está en mi alma vuestro gesto,
y cuanto yo escribir de vos deseo;
vos sola lo escribisteis, yo lo leo
tan solo, que aun de vos me guardo en esto.
En esto estoy y estaré siempre puesto;
que aunque no cabe en mí cuanto en vos veo,
de tanto bien lo que no entiendo creo,
tomando ya la fe por presupuesto.
Yo no nací sino para quereros;
mi alma os ha cortado a su medida;
por hábito del alma mismo os quiero.
Cuando tengo confieso yo deberos;
por vos nací, por vos tengo la vida,
por vos he de morir, y por vos muero.
