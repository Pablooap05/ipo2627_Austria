Titulo: "Mientras por competir"

Autor: "Góngora"

Soneto

Mientras por competir con tu cabello,
oro bruñido, el Sol relumbra en vano,
mientras con menosprecio en medio el llano
mira tu blanca frente el lilio bello;
mientras a cada labio, por cogello,
siguen más ojos que al clavel temprano,
y mientras triunfa con desdén lozano
del luciente cristal tu gentil cuello;
goza cuello, cabello, labio y frente,
antes que lo que fue en tu edad dorada
oro, lilio, clavel, cristal luciente,
no sólo en plata o viola truncada
se vuelva, mas tú y ello juntamente
en tierra, en humo, en polvo, en sombra, en nada
